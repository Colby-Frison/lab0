Job Id,arrival time,Tasks
j8704,296,"[]"
j17452,590,"[]"
j18187,615,"[]"
j27472,919,"[]"
