Job Id,arrival time,Tasks
j1594,64,"[]"
j20480,688,"[]"
