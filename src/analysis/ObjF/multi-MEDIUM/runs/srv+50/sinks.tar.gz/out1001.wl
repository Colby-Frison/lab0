Job Id,arrival time,Tasks
j3747,135,"[]"
j6912,238,"[]"
j20201,678,"[]"
