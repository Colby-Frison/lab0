Job Id,arrival time,Tasks
j1731,90,"[]"
j7257,249,"[]"
j17859,603,"[]"
j21333,715,"[]"
