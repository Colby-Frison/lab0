Job Id,arrival time,Tasks
j5492,192,"[]"
j7115,245,"[]"
j12037,410,"[]"
j20115,675,"[]"
