Job Id,arrival time,Tasks
j1784,69,"[]"
j14788,502,"[]"
j16262,549,"[]"
j19045,641,"[]"
