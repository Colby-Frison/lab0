Job Id,arrival time,Tasks
j6680,230,"[]"
j15363,520,"[]"
j17895,604,"[]"
j26813,897,"[]"
