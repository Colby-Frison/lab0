Job Id,arrival time,Tasks
j1953,75,"[]"
j18918,637,"[]"
j19299,650,"[]"
j20253,680,"[]"
