Job Id,arrival time,Tasks
j1594,63,"[]"
j11947,407,"[]"
j23071,771,"[]"
