Job Id,arrival time,Tasks
j17473,591,"[]"
j19677,662,"[]"
j28715,960,"[]"
