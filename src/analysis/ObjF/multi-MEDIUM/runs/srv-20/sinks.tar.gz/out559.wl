Job Id,arrival time,Tasks
j2350,90,"[]"
j19117,652,"[]"
j20951,703,"[]"
j27612,928,"[]"
