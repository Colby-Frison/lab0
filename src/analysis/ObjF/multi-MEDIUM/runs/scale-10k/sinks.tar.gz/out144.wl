Job Id,arrival time,Tasks
j580,30,"[]"
j2258,85,"[]"
j7584,260,"[]"
j9985,340,"[]"
